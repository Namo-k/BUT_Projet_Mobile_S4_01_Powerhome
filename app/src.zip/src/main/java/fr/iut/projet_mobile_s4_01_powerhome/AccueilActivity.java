package fr.iut.projet_mobile_s4_01_powerhome;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class AccueilActivity extends AppCompatActivity {

    private Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil);

        ListView listView = findViewById(R.id.equipementPrincipauxlistView);
        ImageView modifProfilBtn = (ImageView) findViewById(R.id.modifProfilBtn);

        Intent intent = getIntent();
        if (intent != null) {
            id = intent.getIntExtra("id", 0);
        }

        modifProfilBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditProfileActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                finish();
            }
        });

        List<EquipementPrincipaux> equipementPrincipaux = new ArrayList<>();

        equipementPrincipaux.add(new EquipementPrincipaux(1, "Lave-Linge", 190, 4));
        equipementPrincipaux.add(new EquipementPrincipaux(1, "Lave-Linge", 190, 4));
        equipementPrincipaux.add(new EquipementPrincipaux(1, "Lave-Linge", 190, 4));
        equipementPrincipaux.add(new EquipementPrincipaux(1, "Lave-Linge", 190, 4));

        EquipementPrincipauxAdapter adapter = new EquipementPrincipauxAdapter(this, equipementPrincipaux);
        listView.setAdapter(adapter);
    }
}